export class Jouet {
    public id!:number;
    public ref! :string;
    public libelle!:string;
    public modele!:string;
    public img!:string;
    public prix!:number;
}
