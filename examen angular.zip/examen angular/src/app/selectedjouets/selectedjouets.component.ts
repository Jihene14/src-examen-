import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Jouet } from '../jouet';
import { JouetService } from '../jouet.service';

@Component({
  selector: 'app-selectedjouets',
  templateUrl: './selectedjouets.component.html',
  styleUrls: ['./selectedjouets.component.css']
})
export class SelectedjouetsComponent implements OnInit {

  prixJ!:number;
  modeleJ!:String;
  jeux!:Jouet[];
  lesJeux!:Jouet[];
  constructor(private activatedRoute:ActivatedRoute,private js:JouetService) { }

  ngOnInit(): void {
    this.js.getJouets().subscribe(data=>this.lesJeux=data);
  this.prixJ=this.activatedRoute.snapshot.params['prix'];
  this.modeleJ=this.activatedRoute.snapshot.params['modele'];
  this.js.getJouets().subscribe(data=>this.jeux=data)
  }

}
