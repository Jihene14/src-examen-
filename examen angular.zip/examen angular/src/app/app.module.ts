import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BasComponent } from './bas/bas.component';
import { JouetsComponent } from './jouets/jouets.component';
import { NavComponent } from './nav/nav.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { SelectedjouetsComponent } from './selectedjouets/selectedjouets.component';
import { AjoutjouetComponent } from './ajoutjouet/ajoutjouet.component';
import {HttpClientModule} from "@angular/common/http";
import { FormGroup, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    BasComponent,
    JouetsComponent,
    NavComponent,
    NotFoundComponent,
    SelectedjouetsComponent,
    AjoutjouetComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
