import { Component, OnInit } from '@angular/core';
import { Jouet } from '../jouet';
import { JouetService } from '../jouet.service';

@Component({
  selector: 'app-jouets',
  templateUrl: './jouets.component.html',
  styleUrls: ['./jouets.component.css']
})
export class JouetsComponent implements OnInit {

  jouets!:Jouet[];
  constructor(private js:JouetService) { }

  ngOnInit() {
  this.js.getJouets().subscribe(data=>this.jouets=data);
  }
  

}
