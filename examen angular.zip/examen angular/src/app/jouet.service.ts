import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Jouet } from './jouet';


const URL='http://localhost:3000/jouets';
@Injectable({
  providedIn: 'root'
})
export class JouetService {

  constructor(private http:HttpClient) { }

  getJouets():Observable<Jouet[]>{
    return this.http.get<Jouet[]>(URL);
  }
  ajouterJouet(j:Jouet):Observable<Jouet>
  {
    return this.http.post<Jouet>(URL,j);
  }
}
