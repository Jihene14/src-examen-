import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { JouetService } from '../jouet.service';

@Component({
  selector: 'app-ajoutjouet',
  templateUrl: './ajoutjouet.component.html',
  styleUrls: ['./ajoutjouet.component.css']
})
export class AjoutjouetComponent implements OnInit {

  productForm!:FormGroup;
  
  constructor(private js:JouetService,private fb:FormBuilder,private router:Router) { }

  
  ngOnInit(): void {
    this.productForm=this.fb.nonNullable.group(
      {
        ref:['0',Validators.required],
        libelle:['libelle',[Validators.required,Validators.pattern('[A-Z][a-z]')]],
        modele:['standard'],
        prix:[0],
  
      }
    );
  }
  onAjouter()
  {
    this.js.ajouterJouet(this.productForm.value).subscribe(data=>console.log(data));
    this.router.navigate(['/jeux']);
  }
 get ref()
 {
  return this.productForm.get('ref');
 }
 get libelle()
 {
  return this.productForm.get('libelle');
 }
 onReset(){
  this.productForm.reset({ref:'0',libelle:"libelle",modele:"standars",prix:0});
  }
  
}