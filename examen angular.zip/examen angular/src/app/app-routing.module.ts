import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutjouetComponent } from './ajoutjouet/ajoutjouet.component';
import { JouetsComponent } from './jouets/jouets.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { SelectedjouetsComponent } from './selectedjouets/selectedjouets.component';

const routes: Routes = [
  {path:'jeux',title:'Liste des jouets',component:JouetsComponent},
  {path:'ajouterJeux',title:'Ajout d un jouet',component:AjoutjouetComponent},
  {path:'jeux/:modele/:prix',title:'Selection de jouets',component:SelectedjouetsComponent},
  {path:'',redirectTo:'jeux',pathMatch:'full'},
  {path:'**',title:'not found',component:NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
